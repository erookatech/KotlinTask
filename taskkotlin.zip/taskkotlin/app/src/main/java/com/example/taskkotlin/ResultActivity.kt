package com.example.taskkotlin

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class ResultActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_result)

        val btnSendEmail = findViewById<Button>(R.id.btnSendEmail)
        val btnCall = findViewById<Button>(R.id.btnCall)
        val btnShare = findViewById<Button>(R.id.btnShare)

        // 1. Отправка Email
        btnSendEmail.setOnClickListener {
            val emailIntent = Intent(Intent.ACTION_SENDTO).apply {
                data = Uri.parse("mailto:")
                putExtra(Intent.EXTRA_EMAIL, arrayOf("example@mail.com"))
                putExtra(Intent.EXTRA_SUBJECT, "Тема письма")
                putExtra(Intent.EXTRA_TEXT, "Привет! Это тестовое сообщение из приложения.")
            }
            startActivity(Intent.createChooser(emailIntent, "Выберите почтовый клиент"))
        }

        // 2. Открытие номеронабирателя (Звонок)
        btnCall.setOnClickListener {
            val callIntent = Intent(Intent.ACTION_DIAL).apply {
                data = Uri.parse("tel:+77001234567")
            }
            startActivity(callIntent)
        }

        // 3. Поделиться текстом
        btnShare.setOnClickListener {
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, "Привет! Посмотри мою личную страницу в приложении.")
            }
            startActivity(Intent.createChooser(shareIntent, "Поделиться через"))
        }
    }
}