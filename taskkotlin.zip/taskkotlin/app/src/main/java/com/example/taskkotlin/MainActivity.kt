package com.example.taskkotlin

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {

    private lateinit var tvPinDisplay: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvPinDisplay = findViewById(R.id.tvPinDisplay)

        val digitButtons = listOf<Button>(
            findViewById(R.id.btn0),
            findViewById(R.id.btn1),
            findViewById(R.id.btn2),
            findViewById(R.id.btn3),
            findViewById(R.id.btn4),
            findViewById(R.id.btn5),
            findViewById(R.id.btn6),
            findViewById(R.id.btn7),
            findViewById(R.id.btn8),
            findViewById(R.id.btn9)
        )

        // Нажатие на цифры
        for (btn in digitButtons) {
            btn.setOnClickListener {
                if (tvPinDisplay.text.length < 4) {
                    tvPinDisplay.append(btn.text)
                }
            }
        }

        // Очистка последнего символа (кнопка C)
        findViewById<Button>(R.id.btnClear).setOnClickListener {
            val currentText = tvPinDisplay.text.toString()
            if (currentText.isNotEmpty()) {
                tvPinDisplay.text = currentText.dropLast(1)
            }
        }

        // Проверка кода (кнопка OK)
        findViewById<Button>(R.id.btnOk).setOnClickListener {
            if (tvPinDisplay.text.toString() == "1567") {
                Toast.makeText(this, getString(R.string.correct_pin_toast), Toast.LENGTH_SHORT).show()
            }
        }
    }
}