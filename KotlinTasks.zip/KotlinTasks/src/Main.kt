import kotlin.math.pow
import kotlin.math.sqrt


data class Point(val x: Double, val y: Double) {
    fun distanceTo(other: Point): Double {
        return sqrt((x - other.x).pow(2) + (y - other.y).pow(2))
    }
}


class Triangle(val a: Point, val b: Point, val c: Point) {

    val sideA: Double get() = b.distanceTo(c)
    val sideB: Double get() = a.distanceTo(c)
    val sideC: Double get() = a.distanceTo(b)

    fun perimeter(): Double {
        return sideA + sideB + sideC
    }

    fun area(): Double {
        val p = perimeter() / 2
        return sqrt(p * (p - sideA) * (p - sideB) * (p - sideC))
    }

    fun print() {
        println("=== Описание треугольника ===")
        println("Вершины: A(${a.x}, ${a.y}), B(${b.x}, ${b.y}), C(${c.x}, ${c.y})")
        println("Длины сторон: AB = %.2f, BC = %.2f, CA = %.2f".format(sideC, sideA, sideB))
        println("Периметр: %.2f".format(perimeter()))
        println("Площадь: %.2f".format(area()))
        println("==============================")
    }
}

fun main() {
    val p1 = Point(0.0, 0.0)
    val p2 = Point(0.0, 3.0)
    val p3 = Point(4.0, 0.0)

    val triangle = Triangle(p1, p2, p3)
    triangle.print()
}